/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coding;

/**
 *
 * @author DELL
 */
public class Main {
    public static void main(String[]args){
    MainMenu mm = new  MainMenu();
    mm.setVisible(true);
    mm.setLocationRelativeTo(null);

    }
}
